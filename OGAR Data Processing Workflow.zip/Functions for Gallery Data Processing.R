#Functions for cleaning gallery data


#Art Viewing Functions----
#Function to get total time spent with each artwork and number of viewing sessions per artwork for sample
#position_data = the dataframe with the position data
#session_length = default is 0, can be changed to minimum view length (in s) that constitutes a viewing session
looking_art <- function(position_data, session_length = 0){
  
  library(tidyverse)
  
  #Get unique visitors
  gal_id <- unique(position_data$id)
  
  #Converting viewing time to s
  position_data$fsAdjTime <- position_data$fsAdjTime/1000
  
  #Creating output df
  view <- NULL
  
  #Looping through each person
  for(j in gal_id){
    
    #Subset to just person we're interested in when they're in full screen
    part <- position_data %>%
      filter(id == j) %>%
      filter(fullscreen == TRUE)
    
    if(nrow(part) == 0) {
      
      next
      
    }
    
    #Getting index of when a person changed what they were looking at
    ind <- c(1, which(c(FALSE, part$lookingAt != lag(part$lookingAt))) - 1, nrow(part))
    
    #Tibble to store individual sessions
    temp <- as_tibble(matrix(NA, ncol = 4))
    
    colnames(temp) <- c("id", "session", "lookingAt", "time")
    
    
    #Getting length of time spent in each unique viewing session
    for(i in 1:(length(ind)-1)){
      
      start <- ind[i]
      end <- ind[i+1]
      
      x <- part[c(start, end),]
      
      session <- tibble(x$id[1], i, x$lookingAt[1], (x$fsAdjTime[2] - x$fsAdjTime[1]))
      
      colnames(session) <- c("id", "session", "lookingAt", "time")
      
      
      if(session$time < session_length){
       
        
        session$lookingAt <- ifelse(session$lookingAt == "None", "None",
                                    ifelse(session$lookingAt == "wall", "wall", "not_valid"))
        
      }
      
      temp <- bind_rows(temp, session)
      
    }
    
    if(nrow(temp) == 1) {
      
      next
      
    }
    
    #Grouping viewing sessions of the same object to get total time with each object
    #Also pivot so that each object is a column with time as each value; each person has a row
    total <- temp %>%
      filter(!is.na(id)) %>%
      group_by(lookingAt) %>%
      summarize(total_time = sum(time)) %>%
      bind_cols(id = temp$id[2]) %>%
      pivot_wider(id_cols = id, names_from = lookingAt, values_from = total_time)
    
    #Getting the total time each person spent viewing art
    if(any(colnames(total) == "None")){
      
      if(session_length != 0){
        
        total_time <- total %>%
          select(!c(None, wall, not_valid, id)) %>%
          summarize(total_art = rowSums(across(where(is.numeric)), na.rm = TRUE))
        
        
      }else{
        
        total_time <- total %>%
          select(!c(None, wall, id)) %>%
          summarize(total_art = rowSums(across(where(is.numeric)), na.rm = TRUE))
        
        
      }

    }else{
      
      if(session_length != 0){
        
        total_time <- total %>%
          select(!c(wall, not_valid, id)) %>%
          summarize(total_art =  rowSums(across(where(is.numeric)), na.rm = TRUE))
        
        
      }else{
        
        total_time <- total %>%
          select(!c(wall, id)) %>%
          summarize(total_art = rowSums(across(where(is.numeric)), na.rm = TRUE))
        
        
      }
      
    }
    
    #Grouping viewing sessions to obtain how many viewing sessions occurred per artwork
    #Removes counts for None and Wall
    #Also pivot so that each artwork is a column with number of sessions as each value; each person has a row
    
    num_visit <- as.data.frame(table(temp$lookingAt))
    
    num_art <- num_visit %>%
      filter(!(Var1 %in% c("wall", "None", "not_valid")))
    
    num_visit$Var1 <- paste0("num_", num_visit$Var1)
    
    num_visit <- pivot_wider(num_visit, names_from = Var1, values_from = Freq)
    
    num_visit$num_art_visited <- nrow(num_art)
    
    #Add number of sessions column to total time per art, and total time viewing art
    total <- bind_cols(total, total_time, num_visit)

    #Adding new participants to output df
    view <- bind_rows(view, total)
    
  }
  
  if(session_length != 0){
    
    view <- view %>%
      select(order(colnames(view))) %>%
      select(!c("num_wall", "num_None", "num_not_valid")) %>%
      relocate(id, None, wall, not_valid, total_art, num_art_visited)
    
    
  }else{
    
    view <- view %>%
      select(order(colnames(view))) %>%
      select(!c("num_wall", "num_None")) %>%
      relocate(id, None, wall, total_art, num_art_visited)
    
    
  }
  
  
  return(view)
  
}


#Navigation Functions----

#Proportion of time stopped vs moving for each participant
#position_data = the dataframe of position information imported from .csv
stopped_proportion <- function(position_data){
	
  library(tidyverse)
  
  #Get unique visitors
  gal_id <- unique(position_data$id)
  
  #Creating output df
  move <- NULL
  
  #Looping through each person
  for(j in gal_id){
    
    #Subset to just person we're interested in
    temp <- position_data %>%
      filter(id == j) %>%
      filter(fullscreen == TRUE)
    
    if(nrow(temp) == 0) {
      
      next
      
    }
    
    #Notating whether people were stopped or moving at each time sample

    temp$stopped <- TRUE
    
    for (i in 1:nrow(temp)){
      if (temp$speed[[i]] > 0){
        temp$stopped[[i]] <- FALSE
      }
    }
    
    #Tabulating total time stopped, moving
    stopped <- (sum(temp$stopped == TRUE))/i #proportion of total time spent stopped
    moving <- (sum(temp$stopped == FALSE))/i #proportion of total time spent moving 
    
    #Tabulating time stopped, moving while looking at art
    art <- temp %>%
      filter(lookingAt != "None") %>%
      filter(lookingAt != "wall") 
    
    if(nrow(art) == 0){
      
      stopped_art <- 0
      moving_art <- 0
      
    }else{
      
      stopped_art <- (sum(art$stopped == TRUE))/i 
      moving_art <- (sum(art$stopped == FALSE))/i 
      
    }
    
    ind <- tibble(j, stopped, moving, stopped_art, moving_art)
    
    colnames(ind) <- c("id", "stopped", "moving", "stopped_art", "moving_art")
    
    #Binding each person's data to output file
    move <- bind_rows(move, ind)
    
  }
  
	return(move)
  
}


#Other Helpful Functions----

#Draw a gallery floorplan with indicators for artwork placement
#jsonpath = path to the .json gallery definition
draw_gal <- function(jsonpath){
  
  library(jsonlite)
  library(ggplot2)
  
  #Getting gallery definition and wall segments
  gallery <- fromJSON(jsonpath)
	walls <- gallery$walls
	wallsegcount <- length(walls)
	
	#walldf is a dataframe of line segments to draw
	walldf <- data.frame(matrix(ncol = 4, nrow = 0))
	colnames(walldf) <- c('x1','y1','x2','y2')
	
	wallsegidx <- 1
	
	#iterate through every wall group
	while(wallsegidx <= wallsegcount){
		wallseg <- walls[[wallsegidx]]
		wallptcount <- length(wallseg)/2
		wallptidx <- 2
		
		#in this wall group, iterate through numbers two at a time
		while(wallptidx <= wallptcount){
			x1 <- wallseg[(wallptidx-1)*2-1]
			y1 <- wallseg[(wallptidx-1)*2]
			x2 <- wallseg[wallptidx*2-1]
			y2 <- wallseg[wallptidx*2]
			
			#make a dataframe to hold just this line segment
			segdf <- data.frame(x1,y1,x2,y2)
			colnames(segdf) <- c('x1','y1','x2','y2')
			
			#add it to the overall one
			walldf <- rbind(walldf, segdf)
			wallptidx <- wallptidx+1
			
		}
		
		wallsegidx <- wallsegidx+1
		
	}
	
	walldraw <- geom_segment(mapping = aes(x=x1, y=y1, xend=x2, yend=y2), data = walldf, linewidth=unit(.15, "mm"), lineend="round", linejoin="round")
	
	#getting artwork locations
	art <- gallery$artPlacement
	
	art_loc <- data.frame(matrix(unlist(art$loc), nrow = length(gallery$art), byrow = TRUE))
	colnames(art_loc) <- c("x", "y")
	
	#creating geom for artwork placements
	artdraw <- geom_point(mapping = aes(x=x, y=y), data = art_loc, size = 1.5, color = "black")
	
	floorplan <- ggplot()  + walldraw + artdraw + theme_void()
	
	#wall segments are returned as a dataframe of lines defined by their starting and ending coordinate points
	return(floorplan)
	
}


#Descriptive statistics----

#Get descriptives for how long each artwork is viewed
#processed_data = the output from the "looking_art" function or a data.frame or tibble containing that output
#art_cols = a vector containing the column numbers containing the artwork columns output from "looking_art"
art_desc <- function(processed_data, art_cols){
  
  desc <- as_tibble(matrix(NA, ncol = 6, dimnames = list(NULL, c("Art", "M", "SD", "Med",
                                                                          "Min", "Max"))))
  
  art_count <- 1
  
  for(i in art_cols){
    
    row <- i - (min(art_cols) - 1)
    
    art <- pull(processed_data[, i])
    
    desc[row, 1] <- colnames(processed_data)[i]
    desc[row, 2] <- mean(art, na.rm = TRUE)
    desc[row, 3] <- sd(art, na.rm = TRUE)
    desc[row, 4] <- median(art, na.rm = TRUE)
    desc[row, 5] <- min(art, na.rm = TRUE)
    desc[row, 6] <- max(art, na.rm = TRUE)
    
    art_count <- art_count + 1
    
  }
  
  desc <- cbind(desc[, 1], round(desc[, 2:6], 2))
  
  return(desc)
  
}



#Get descriptives for time in gallery, distance traveled, proportion of time viewing art, time stopped with art, and number of artworks visited
#combined_data = a merged data set for the participant_processed file, the "looking_art" function output, and the "stopped_proportion" output
gal_desc <- function(combined_data){
  
  desc <- as_tibble(matrix(NA, ncol = 6, dimnames = list(NULL, c("Variable", "M", "SD", "Med",
                                                                      "Min", "Max"))))
  
  var_labels <- c("Time in Gallery", "Distance Traveled", "Prop. Time Viewing Art", 
                          "Prop. Time Stopped with Art", "Num. Artworks Visited")
  
  combined_data$totalFsTime <- combined_data$totalFsTime/1000
  
  combined_data$prop_art <- combined_data$total_art/combined_data$totalFsTime
  
  vars <- c("totalFsTime", "totalDistance", "prop_art", "stopped_art", "num_art_visited")
  
  for(i in 1:length(vars)){
    
    desc[i, 1] <- var_labels[i]
    desc[i, 2] <- mean(pull(combined_data[,vars[i]]), na.rm = TRUE)
    desc[i, 3] <- sd(pull(combined_data[,vars[i]]), na.rm = TRUE)
    desc[i, 4] <- median(pull(combined_data[,vars[i]]), na.rm = TRUE)
    desc[i, 5] <- min(pull(combined_data[,vars[i]]), na.rm = TRUE)
    desc[i, 6] <- max(pull(combined_data[,vars[i]]), na.rm = TRUE)
    
  }
  
  desc <- cbind(desc[, 1], round(desc[, 2:6], 2))
  
  return(desc)
  
}



#including example data for work flow
example_participant <- read_csv("Example_participant.csv")

example_position <- read_csv("Example_position.csv")

example_gallery <- "Example gallery.json"
